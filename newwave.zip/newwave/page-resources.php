
<?php
/*
Template Name: About Page
*/ 
		get_header();
		require_once('components/navbar.inc.php');
 ?>

 <div style="width: 100%; background-image: url('/wp-content/themes/newwave/images/4.png');background-size: cover; padding: 30px;">
 	<center>
 		<h1>Free Resources</h1>
 		<p>Take these courses and download our ebooks. They are all free! </p>
 	</center>
 	<br>
 </div>

 <div class="row">
 	<div class="col-md-6">
 		<img src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 	</div>
 	<div class="col-md-6" style="margin-top: 30px; padding: 30px">
 		<p>
 			Newwave Digital School is an E-learning Academy established by Newwave Digital Solutions to help create access to education remotely, without barriers, limitations and excuses.
 		</p>
 		<p>
 			With the E-learning Academy,one cn get skilled, learn business, and be awarded certificates that wouldbe equivalent to studying in physical locations.
 		</p>
 		<p>
 			Our resource persons are Certified.	<br>
 			Our courses are free.
 		</p>
 	</div>
 </div>

 <hr>
 <div class="container">
 	<h1>Ebooks</h1>
 	<div class="row">
 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Artificial Intelligence</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Big Data</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Data Science</h3></center>
 		</div>
 	</div>


 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Financial Education</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Robotics</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Mathematics</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Video Editing</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Machine Learning</h3></center>
 		</div>
 	</div>

 </div>

 <hr>
 <div class="container">
 	<h1>Free Courses</h1>
 	<div class="row">
 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Artificial Intelligence</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Big Data</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Data Science</h3></center>
 		</div>
 	</div>


 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Financial Education</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Robotics</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Mathematics</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Video Editing</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Machine Learning</h3></center>
 		</div>
 	</div>

 </div>

 <?php get_footer(); ?>