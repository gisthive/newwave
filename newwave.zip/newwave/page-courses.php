
<?php
/*
Template Name: Courses Page
*/ 
		get_header();
		require_once('components/navbar.inc.php');
 ?>

 <div style="width: 100%; background-image: url('/wp-content/themes/newwave/images/4.png');background-size: cover; padding: 30px;">
 	<center>
 		<h1>Courses We Offer</h1>
 		<p>Fill up the forms and enjoy your training. </p>
 	</center>
 	<br>
 </div>

 <div class="row">
 	<div class="col-md-6 row" style="padding: 20px">
 		<div class="col-6 col-md-6">
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Animation Design</h3></center>
 		</div>
 		<div class="col-6 col-md-6">
 			<h3>Description</h3>
 			<p>Description of the course goes here</p>
 			<h3>Duration</h3>
 			<p>3 weeks </p>
 			<h3>Fee</h3>
 			<p>20,000</p>
 		</div>
 	</div>

 	<div class="col-md-6 row" style="padding: 20px">
 		<div class="col-6 col-md-6">
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Coding and Programming</h3></center>
 		</div>
 		<div class="col-6 col-md-6">
 			<h3>Description</h3>
 			<p>Description of the course goes here</p>
 			<h3>Duration</h3>
 			<p>3 weeks </p>
 			<h3>Fee</h3>
 			<p>20,000</p>
 		</div>
 	</div>

 	<div class="col-md-6 row" style="padding: 20px">
 		<div class="col-6 col-md-6">
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>App Development</h3></center>
 		</div>
 		<div class="col-6 col-md-6">
 			<h3>Description</h3>
 			<p>Description of the course goes here</p>
 			<h3>Duration</h3>
 			<p>3 weeks </p>
 			<h3>Fee</h3>
 			<p>20,000</p>
 		</div>
 	</div>

 	<div class="col-md-6 row" style="padding: 20px">
 		<div class="col-6 col-md-6">
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Web Development</h3></center>
 		</div>
 		<div class="col-6 col-md-6">
 			<h3>Description</h3>
 			<p>Description of the course goes here</p>
 			<h3>Duration</h3>
 			<p>3 weeks </p>
 			<h3>Fee</h3>
 			<p>20,000</p>
 		</div>
 	</div>
 </div>
<hr>
 <div class="container">
 	<h1>New Courses<br><small>To be Unveiled</small></h1>
 	<div class="row">
 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Artificial Intelligence</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Big Data</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Data Science</h3></center>
 		</div>
 	</div>


 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Financial Education</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Robotics</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Mathematics</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Video Editing</h3></center>
 		</div>
 	</div>

 	<div class="col-md-3 col-6 row" style="padding: 20px">
 		<div>
 			<img alt="Course Image here" src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 			<center><h3>Machine Learning</h3></center>
 		</div>
 	</div>

 </div>

 <hr>

 <div class="jumbotron col-12" style="background-color: #FF6347;">
	<div class="row">
		<div class="col-md-9">
  	<h1><span style="color: yellow">COMING SOON!!!</span><br>
  		<small>NEW WAVE DIGITAL E-LERNING COURSE</small></h1>

  	<p><b>A 12-weekIntensive Course on E-learning and digital skills training. Anybody can apply.</b></p>
  	
  </div>
  <div class="col-md-3">
  	<a href="" class="btn btn-primary"> Register <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
  	<p>Book an early seat to stand a chance of winning fantastic prizes</p>
  </div>
	</div>
  
</div>

 <?php get_footer(); ?>