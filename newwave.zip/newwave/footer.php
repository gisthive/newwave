<?php wp_footer(); ?>


<footer style="background-color: #3B599B; padding: 20px; color: black" class="">
      <div class="row">
        <div class="col-12 col-md">
          New Wave Logo Here
        </div>
        <div class="col-6 col-md">
          <ul class="list-unstyled">
            <li><a class="black-text" href="#">About Us</a></li>
            <li><a class="black-text" href="#">Courses</a></li>
            <li><a class="black-text" href="#">Blog</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <ul class="list-unstyled">
            <li><a class="black-text" href="#">Contact Us</a></li>
            <li><a class="black-text" href="#">Terms and Conditions</a></li>
            <li><a class="black-text" href="#">Privacy Policy</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Follow Us</h5>
          <ul class="list-unstyled text-small">
            <li><a class="black-text" href="#">Facebook</a></li>
            <li><a class="black-text" href="#">Twitter</a></li>
            <li><a class="black-text" href="#">Instagram</a></li>
          </ul>
        </div>

      </div>
        <center style="padding: 10px">Copyright 2020. New Wave Digital School *|* All Rights Reserved. </center>
    </footer>
</body>
</html>