<?php 
		get_header();
		require_once('components/navbar.inc.php');
 ?>

<!-- No.1 -->
<div class="jumbotron col-12" style="background-image: url('/wp-content/themes/newwave/images/1.png');background-size: cover;">
	<div class="row">
		<div class="col-9">
  	<p style="color: white"> Fast Track Your</p>
  	<h1>Digital Learning Process</h1>
  	<a href="" class="btn btn-primary"> Get Started <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
  </div>
  <div class="col-3">
  	<img class="img-fluid" src='wp-content/themes/newwave/images/img.png'>
  </div>
	</div>
  
</div>


<!-- No.2 -->
<div style="margin-top: -32px; width:100%; background-image: url('/wp-content/themes/newwave/images/2.png');background-size: cover; padding: 40px">

	<div class="row">

		<div class='col-md-6'>
			<h1>Courses<br><small>We Offer</small></h1>
			<p>We give certificates for the courses we offer and they are taken by highly trained proffessionals in the eductaion and tech world.</p>
			<a href="" class="btn btn-danger"> View Courses <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
		</div>


		<div class="col-md-6" style="padding: 30px">
			<div class="row">
				<div class="col-6 col-md-6" style="background-color: #E49E00; box-shadow: -2px -5px 3px 3px #ffff7f;margin-left: -10px">
					<h3><i class="fa fa-cloud" aria-hidden="true"></i><br>
					Web Development</h3>
				</div><br>
			<div class="col-6 col-md-6" style="background-color: #E49E00; box-shadow: -2px -5px 3px 3px #ffff7f;margin-right: 10px">
				<h3><i class="fa fa-home" aria-hidden="true"></i><br>
						Graphics Design</h3>
					</div><br>
			<div class="col-6 col-md-6" style="background-color: #E49E00; box-shadow: -2px -5px 3px 3px #ffff7f;margin-left: -10px">
				<h3><i class="fa fa-bullhorn" aria-hidden="true"></i><br>
						Digital Marketing</h3>
					</div><br>
			<div class="col-6 col-md-6" style="background-color: #E49E00; box-shadow: -2px -5px 3px 3px #ffff7f;margin-right: 10px">
				<h3><i class="fa fa-globe" aria-hidden="true"></i><br>
						Blockchain Technology</h3>
					</div>
	</div>
	</div><!--end No.2 row-->


	</div>
</div>

	<!-- No.3 -->
<div class="jumbotron col-12" style="background-color: #FF6347;">
	<div class="row">
		<div class="col-9">
  	<h1><span style="color: white">New Wave </span><span style="color: yellow">Digital School</span></h1>
  	<p><b>Promoting the realities of Education theough E-learning</b></p>
  	
  </div>
  <div class="col-3">
  	<a href="" class="btn btn-primary"> Learn More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
  </div>
	</div>
  
</div>

<!-- No.4 -->
<div style="margin-top: -32px; width:100%; background-image: url('/wp-content/themes/newwave/images/4.png');background-size: cover; padding: 40px">

	<h1>Trending Courses</h1>

	<div class="row">

		<div class='col-md-4' style="padding: 10px;background-color: white; box-shadow: -1px -3px 1px 1px grey;">
			<h3>Coding & Programming</h3>
		</div>
		<div class='col-md-4' style="padding: 10px;background-color: white; box-shadow: -1px -3px 1px 1px grey;">
			<h3>App Development</h3>
		</div>
		<div class='col-md-4' style="padding: 10px;background-color: white; box-shadow: -1px -3px 1px 1px grey;">
			<h3>Animation and Design</h3>
		</div>

	</div>
	<a href="">View All Courses <i class="fa fa-arrow-right" aria-hidden="true"></i></a>

</div>


<?php get_footer(); ?>