
<?php
/*
Template Name: About Page
*/ 
		get_header();
		require_once('components/navbar.inc.php');
 ?>

 <div style="width: 100%; background-image: url('/wp-content/themes/newwave/images/4.png');background-size: cover; padding: 30px;">
 	<center>
 		<h1>Who We Are</h1>
 		<p>We are focused on driving change through Education and skill acquisition. We hope to break the chain of illiteracy, poverty,hunger and laziness by educating everyone and ensuring they learn early to leverage their skills in the market place. </p>
 	</center>
 	<br>
 </div>

 <div class="row">
 	<div class="col-md-6">
 		<img src="/wp-content/themes/newwave/images/img.png" class="img-fluid">
 	</div>
 	<div class="col-md-6" style="margin-top: 30px; padding: 30px">
 		<p>
 			Newwave Digital School is an E-learning Academy established by Newwave Digital Solutions to help create access to education remotely, without barriers, limitations and excuses.
 		</p>
 		<p>
 			With the E-learning Academy,one cn get skilled, learn business, and be awarded certificates that wouldbe equivalent to studying in physical locations.
 		</p>
 		<p>
 			Our resource persons are Certified.	<br>
 			Our courses are free.
 		</p>
 	</div>
 </div>

 <?php get_footer(); ?>