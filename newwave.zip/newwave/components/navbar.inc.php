<nav style="background-image: url('/wp-content/themes/newwave/images/1.png');background-size: cover;" class="navbar navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="#">New Wave Digital School</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
          </li><li class="nav-item active">
            <a class="nav-link" href="/about">About <span class="sr-only">(current)</span></a>
          </li><li class="nav-item active">
            <a class="nav-link" href="/courses">Courses <span class="sr-only">(current)</span></a>
          </li><li class="nav-item active">
            <a class="nav-link" href="resources">Free Resources <span class="sr-only">(current)</span></a>
          </li><li class="nav-item active">
            <a class="nav-link" href="/#contact">Contact <span class="sr-only">(current)</span></a>
          </li>
        </ul>
          <a href="/wp-login.php" class="btn btn-outline-success my-2 my-sm-0" type="submit">Log In</a>
      </div>
    </nav>